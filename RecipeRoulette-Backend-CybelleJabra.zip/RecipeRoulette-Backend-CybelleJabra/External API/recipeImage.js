const axios = require('axios');

// external API to retrieve images for recipes from Pixabay
const getPixabayImages = async (query) => {
  const apiKey = '43955200-5a24d9cb7bbebf682d3f5634a';
  // uses this URL to retrieve the image
  const url = `https://pixabay.com/api/?key=${apiKey}&q=${encodeURIComponent(query)}&image_type=photo`;

  try {
    const response = await axios.get(url);
    if (response.data.hits.length > 0) {
      return response.data.hits[0].webformatURL; 
    } else {
      return null; 
    }
  } catch (error) {
    console.error('Error fetching images from Pixabay:', error.message);
    throw error;
  }
};

module.exports = {
  getPixabayImages,
};
