const User = require('../Models/user'); 

// service to update a user's bio
const updateUserBio = async (username, newBio) => {
    try {

        // utilizes update to update the bio from Bio to newBio
        const [updated] = await User.update(
            { Bio: newBio }, 
            { where: { Username: username } }
        );

        if (!updated) {
            throw new Error("User not found or bio not updated");
        }

        return { username: username };
    } catch (error) {
        throw new Error(error.message); 
    }
};

// service to check if user exists by username
const findUserByUsername = async (username) => {
    try {
        const user = await User.findOne({ where: { Username: username } });
        return user; // Returns the user if found, otherwise null
    } catch (error) {
        console.error("Error fetching user by username:", error);
        throw error;
    }
};

// service to check if user exists by user email
const findUserByEmail = async (email) => {
    try {
        const user = await User.findOne({ where: { Email: email } });
        return user; // Returns the user if found, otherwise null
    } catch (error) {
        console.error("Error fetching user by email:", error);
        throw error;
    }
};

// service to find userID by the username
const findUserIdByUsername = async (username) => {
    try {
        const user = await User.findOne({ where: { Username: username }, attributes: ['UserID'] });

        if (!user) {
            throw new Error("User not found");
        }
        return user.UserID; 
    } catch (error) {
        throw new Error(error.message);
    }
};

// service to find username by userID
const findUsernameByUserId = async (userId) => {
    try {
        const user = await User.findOne({ where: { UserID: userId }, attributes: ['Username'] });

        if (!user) {
            throw new Error("User not found");
        }

        return user.Username;
    } catch (error) {
        throw new Error(`Error fetching username: ${error.message}`);
    }
};

// service to fetch user's join date from database
const getUserJoinDate = async (username) => {
    try {
        const user = await User.findOne({ where: { Username: username }, attributes: ['JoinDate'] });

        if (!user) {
            throw new Error("User not found");
        }
        return user.JoinDate;
    } catch (error) {
        throw new Error(error.message);
    }
};

// service to fetch user's bio from database
const getUserBio = async (username) => {
    try {
        const user = await User.findOne({ where: { Username: username }, attributes: ['Bio'] });

        if (!user) {
            throw new Error("User not found");
        }
        return user.Bio;
    } catch (error) {
        throw new Error(error.message);
    }
};

module.exports = {
    updateUserBio,
    findUserByUsername,
    getUserJoinDate,
    getUserBio,
    findUserIdByUsername,
    findUsernameByUserId,
    findUserByEmail
};
