const Recipe = require('../Models/recipe');  
const User = require('../Models/user');  
const Cuisine = require('../Models/cuisine');  
const { Op } = require('sequelize');


// service to create a new recipe
const createRecipe = async (recipeData) => {
    try {

        // creates a new recipe with the title, description, ingredients, ...
        const newRecipe = await Recipe.create({
            Title: recipeData.title,
            Description: recipeData.description,
            Ingredients: recipeData.ingredients,
            Instructions: recipeData.instructions,
            DifficultyLevel: recipeData.difficultyLevel,
            CuisineID: recipeData.cuisineID,
            Calories: recipeData.calories,
            UserID: recipeData.userID,
            DietaryPreferences: recipeData.dietaryPreferences,
        });

        return { recipe_id: newRecipe.RecipeID };
    } catch (error) {
        throw new Error(error.message);
    }
};
 

// service to get recipes according to dietary preferences, calories, and preferred cuisine
const getRecipesByCriteria = async (dietaryPreferences, calorieLimitPerMeal, preferredCuisine) => {
    try {

        // utilizes findAll to get all recipes with the specific criteria
        const recipes = await Recipe.findAll({
            where: {
                DietaryPreferences: dietaryPreferences,
                Calories: {
                    [Op.lte]: calorieLimitPerMeal,
                },
                CuisineID: preferredCuisine,
            },
            include: [
                {
                    model: Cuisine,
                    as: 'cuisine',
                    attributes: ['CuisineName'],
                },
            ],
        });

        return recipes;
    } catch (error) {
        throw new Error(`Error retrieving recipes by criteria: ${error.message}`);
    }
};

// service tot get all recipes submitted by a specific user
const getRecipesByUser = async (username) => {
    try {

        // utilizes findAll to get all recipes by a user
        const recipes = await Recipe.findAll({
            include: [
                {
                    model: User,
                    as: 'user',
                    where: { Username: username },
                    attributes: [],
                },
            ],
        });

        return recipes;
    } catch (error) {
        throw new Error(`Error retrieving recipes by user: ${error.message}`);
    }
};


// service to get a specific recipe's details
const getRecipeDetails = async (recipeId) => {
    try {

        // utilizes findOne to get specific recipe from its recipeId
        const recipe = await Recipe.findOne({
            where: { RecipeID: recipeId },

            // gets the username and cuisineName (instead of userId and cuisineId)
            include: [
                {
                    model: Cuisine,
                    as: 'cuisine',
                    attributes: ['CuisineName'],
                },
                {
                    model: User,
                    as: 'user',
                    attributes: ['Username'],
                },
            ],
        });

        if (!recipe) {
            throw new Error("Recipe not found");
        }

        return recipe;
    } catch (error) {
        console.error('Error retrieving recipe details:', error);
        throw new Error(error.message);
    }
};

// service to get all recipes according to title, ingredients, dietary preferences in search query
const searchRecipes = async (searchQuery) => {
    try {
        const recipes = await Recipe.findAll({
            where: {

                // uses sequelize operators (like) to compare search query
                [Op.or]: [
                    {
                        Title: {
                            [Op.like]: `%${searchQuery}%`,
                        },
                    },
                    {
                        Ingredients: {
                            [Op.like]: `%${searchQuery}%`,
                        },
                    },
                    {
                        DietaryPreferences: {
                            [Op.like]: `%${searchQuery}%`,
                        },
                    },
                ],
            },
            include: [
                {
                    model: Cuisine,
                    as: 'cuisine',
                    attributes: ['CuisineName'],
                },
                {
                    model: User,
                    as: 'user',
                    attributes: ['Username'],
                },
            ],
        });

        return recipes;
    } catch (error) {
        throw new Error(`Error searching recipes: ${error.message}`);
    }
};

module.exports = {
    createRecipe,
    getRecipesByCriteria,
    getRecipesByUser,
    getRecipeDetails,
    searchRecipes,
};
