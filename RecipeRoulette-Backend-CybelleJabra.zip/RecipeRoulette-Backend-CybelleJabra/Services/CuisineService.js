const Cuisine = require('../Models/cuisine');

// service to retrieve all cuisines from database
const getCuisines = async () => {
    try {

        // uses findAll to fetch all cuisines
        const cuisines = await Cuisine.findAll({
            attributes: ['CuisineName'],
        });

        // maps them in specific format (cuisineName)
        return cuisines.map(cuisine => cuisine.CuisineName);
    } catch (error) {
        console.error("Error fetching cuisines:", error);
        throw error;
    }
};


// service to get cuisine ID by its name
const getCuisineIdByName = async (cuisineName) => {
    try {

        // uses findOne to fetch specific cuisine 
        const cuisine = await Cuisine.findOne({
            where: { CuisineName: cuisineName },
            attributes: ['CuisineID'],
        });
        if (!cuisine) {
            throw new Error(`Cuisine with name "${cuisineName}" not found`);
        }
        return cuisine.CuisineID;
    } catch (error) {
        console.error(`Error fetching cuisine ID for name "${cuisineName}":`, error);
        throw error;
    }
};

// service to get cuisine Name from its ID
const getCuisineNameById = async (cuisineId) => {
    try {

        // uses findOne to fetch specific cuisine
        const cuisine = await Cuisine.findOne({
            where: { CuisineID: cuisineId },
            attributes: ['CuisineName'],
        });
        if (!cuisine) {
            throw new Error(`Cuisine with ID "${cuisineId}" not found`);
        }
        return cuisine.CuisineName;
    } catch (error) {
        console.error(`Error retrieving cuisine name for ID "${cuisineId}":`, error);
        throw error;
    }
};

module.exports = {
    getCuisines,
    getCuisineIdByName,
    getCuisineNameById,
};
