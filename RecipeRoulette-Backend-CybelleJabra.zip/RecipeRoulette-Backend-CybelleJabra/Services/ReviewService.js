const Review = require('../Models/review');
const User = require('../Models/user'); 
const Recipe = require('../Models/recipe'); 
const sequelize = require('../Config/DBConfig');


// service to create a review
const createReview = async (reviewData) => {
    try {
        // creates the rieview with its data fields
        const review = await Review.create({
            Content: reviewData.content,
            ReviewDate: reviewData.reviewDate || new Date(),
            RecipeID: reviewData.recipeID,
            UserID: reviewData.userID,
            Value: reviewData.value
        });
        return { review_id: review.ReviewID };
    } catch (error) {
        throw new Error(error.message);
    }
};


// service to get reviews belonging to a specific recipe from its ID
const getReviewsByRecipeId = async (recipeId) => {
    try {

        // utilizes findAll to get all reviews for specific recipe
        const reviews = await Review.findAll({
            where: { RecipeID: recipeId },
            include: [{
                model: User,
                as: 'user',
                attributes: ['Username'], 
            }]
        });
        return reviews;
    } catch (error) {
        throw new Error(error.message);
    }
};

// service to get reviews submitted by a specific user from the username
const getReviewsByUser = async (username) => {
    try {

        // utilizes findAll to get all reviews for that specific user
        const reviews = await Review.findAll({
            include: [{
                model: User,
                as: 'user',
                where: { Username: username },
                attributes: [], 
            }]
        });
        return reviews;
    } catch (error) {
        throw new Error(error.message);
    }
};

// service to update average rating when new rating submitted
const updateAverageRating = async (recipeId) => {
    try {
        // utilizes findAll and AVG query to get the average rating value
        const result = await Review.findAll({
            where: { RecipeID: recipeId },
            attributes: [[sequelize.fn('AVG', sequelize.col('Value')), 'avgRating']],
        });

        let avgRating = result[0] ? result[0].get('avgRating') : 0;

        await Recipe.update({ AverageRating: avgRating }, {
            where: { RecipeID: recipeId }
        });
    } catch (error) {
        throw new Error(error.message);
    }
};


// service to delete a specific review
const deleteReview = async (reviewId) => {
    try {

        // utilizes destroy to remove that review using its ID
        const result = await Review.destroy({
            where: { ReviewID: reviewId }
        });
        if (result === 0) {
            throw new Error('Review not found');
        }
    } catch (error) {
        throw new Error(error.message);
    }
};

module.exports = {
    createReview,
    getReviewsByRecipeId,
    getReviewsByUser,
    updateAverageRating,
    deleteReview  
};
