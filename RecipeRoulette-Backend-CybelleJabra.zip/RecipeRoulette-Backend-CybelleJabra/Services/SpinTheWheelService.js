const Recipe = require('../Models/recipe'); 
const { getRecipesByCriteria } = require('./RecipeService');

// service to "spin the wheel" and get random recipe according to dietary preferences, calories and cuisine
const spinTheWheel = async (dietaryPreferences, calorieLimitPerMeal, preferredCuisine) => {
    try {
        // Call getRecipesByCriteria to get recipes based on the criteria
        const recipes = await getRecipesByCriteria(dietaryPreferences, calorieLimitPerMeal, preferredCuisine);

        console.log(`Fetched ${recipes.length} recipes`);

        if (recipes.length === 0) {
            console.log("No recipes found.");
            return null;
        }

        // Randomly select a recipe from the results
        const randomIndex = Math.floor(Math.random() * recipes.length);
        const randomRecipe = recipes[randomIndex];
        console.log(`Selected Recipe: ${randomRecipe.RecipeID}`);

        return randomRecipe;
    } catch (error) {
        console.error('Error during the spinning wheel process:', error);
        throw new Error('Error spinning the wheel');
    }
};

module.exports = { spinTheWheel };

