const User = require('../Models/user'); 
const bcrypt = require("bcrypt");
const { Op } = require('sequelize');
const moment = require('moment');

// service to register use with their credentials
const registerUser = async (username, password, confirmPassword, email) => {
    try {

        // utilizes findOne and sequelize operators to check if user already exists
        const existingUser = await User.findOne({
            where: {
                [Op.or]: [
                    { Username: username }, 
                    { Email: email } 
                ]
            }
        });

        if (existingUser) {
            throw new Error("User already exists");
        }

        if (password !== confirmPassword) {
            throw new Error("Passwords do not match");
        }

        // hashes the password for added security
        const hashedPassword = await bcrypt.hash(password, 12);

        // creates the user
        const newUser = await User.create({
            Username: username,
            Password: hashedPassword, 
            Email: email, 
            JoinDate: moment().format('YYYY-MM-DD')
        });

        return newUser.UserID; 
    } catch (error) {
        console.error("Error in registering user:", error);
        throw error;
    }
};

// service to login a user with credentials
const loginUser = async (username, password) => {
    try {

        // utilizes findOne to check if user exists
        const user = await User.findOne({ where: { Username: username } }); 

        if (!user) {
            throw new Error("Invalid credentials");
        }

        // compares sent password with hashed password
        const isMatch = await bcrypt.compare(password, user.Password);

        if (!isMatch) {
            throw new Error("Invalid credentials");
        }

        return {
            message: "Logged in successfully!",
            userId: user.UserID 
        };
    } catch (error) {
        console.error("Error in logging in user:", error);
        throw error;
    }
}; 

module.exports = {
    registerUser,
    loginUser
};
