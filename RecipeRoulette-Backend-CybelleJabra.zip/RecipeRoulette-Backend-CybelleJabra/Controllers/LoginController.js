const { registerUser, loginUser } = require("../Services/LoginService");
const { validationResult } = require('express-validator');
const { generateToken } = require('../middleware/jwt');
const { findUserByUsername, findUserByEmail } = require('../Services/UserService'); 

// controller to handle registering a user
const registerUserController = async (req, res) => {
    try {
        const { username, password, confirmPassword, email } = req.body;
        console.log("Received values:", { username, password, confirmPassword, email });

        // checks if user already exists by username or email
        const existingUser = await checkIfUserExists(username, email);

        if (existingUser) {
            // user already exists (either by username or email)
            return res.status(400).json({
                message: "Username or email already exists. Please choose a different one."
            });
        }

        // proceeds with registration
        const userId = await registerUser(username, password, confirmPassword, email);
        
        res.status(201).json({ userId, message: "User registered successfully!" });

    } catch (error) {
        console.error("Error registering user:", error);

        if (error.message.includes('password mismatch')) {
            return res.status(400).json({ message: "Passwords do not match." });
        }

        if (error.message.includes('invalid input')) {
            return res.status(400).json({ message: "Invalid input. Please check your details." });
        }

        res.status(500).json({ error: "Internal server error. Please try again later." });
    }
};

// controller to handle checking if the user already exists (by username or email)
const checkIfUserExists = async (username, email) => {
    const userByUsername = await findUserByUsername(username);
    const userByEmail = await findUserByEmail(email);

    if (userByUsername || userByEmail) {
        return true; // User already exists
    }

    return false; // No existing user found
};


// controller to handle logging in a user
const loginUserController = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { username, password } = req.body;

    try {
        const result = await loginUser(username, password);

        if (!result) {
            return res.status(404).json({ message: "User does not exist" });
        }

        // generates token upon successful login
        const token = generateToken({ userId: result.userId, username });

        res.status(200).json({ message: "Login successful!", userId: result.userId, token });
    } catch (error) {
        console.error("Error logging in: ", error);

        if (error.message.includes('Invalid credentials')) {
            return res.status(401).json({ message: "Incorrect password. Please try again." });
        }

        res.status(500).json({ message: "Internal server error. Please try again later." });
    }
};


module.exports = {
    registerUserController,
    loginUserController
};
