const UserService = require("../Services/UserService");
const RecipeService = require('../Services/RecipeService');
const ReviewService = require('../Services/ReviewService');
const { getPixabayImages } = require('../External API/recipeImage');
const moment = require('moment');
const jwt = require('jsonwebtoken');

// controller to handle getting user id from token
const getUserIdFromToken = (token) => {
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        return decoded.userId;
    } catch (error) {
        return null;
    }
};

// controller to handle getting details of own user's profile
const userProfileController = async (req, res) => {
    const token = req.headers['authorization']?.split(' ')[1];
    const userId = getUserIdFromToken(token);

    if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
    }

    try {
        const username = await UserService.getUsernameByUserId(userId);
        const recipes = await RecipeService.getRecipesByUser(username);
        const reviews = await ReviewService.getReviewsByUser(username);
        const joinDate = await UserService.getUserJoinDate(username);
        const bio = await UserService.getUserBio(username);

        const formattedJoinDate = moment(joinDate).format('DD/MM/YY');

        for (let recipe of recipes) {
            const imageUrl = await getPixabayImages(recipe.Title);
            recipe.imageUrl = imageUrl || '/path/to/default/image.jpg';
            recipe.recipeId = recipe.RecipeID;
        }

        for (let review of reviews) {
            const reviewedRecipe = await RecipeService.getRecipeDetails(review.RecipeID);
            review.recipeTitle = reviewedRecipe.Title;
            review.recipeId = reviewedRecipe.RecipeID;
            review.imageUrl = await getPixabayImages(review.recipeTitle) || '/path/to/default/image.jpg';
            review.ratingImage = `/images/${review.value}star.png`;
        }

        res.status(200).json({
            joinDate: formattedJoinDate,
            username: username,
            bio: bio,
            recipes: recipes,
            reviews: reviews
        });
    } catch (error) {
        console.error("Error loading profile:", error);
        res.status(500).json({ error: "Error loading profile" });
    }
};

// controller to handle getting details of another user's profile
const viewUserProfileController = async (req, res) => {
    const { username } = req.params;

    try {
        const recipes = await RecipeService.getRecipesByUser(username);
        const reviews = await ReviewService.getReviewsByUser(username);
        const joinDate = await UserService.getUserJoinDate(username);
        const bio = await UserService.getUserBio(username);

        const formattedJoinDate = moment(joinDate).format('DD/MM/YY');

        for (let recipe of recipes) {
            const imageUrl = await getPixabayImages(recipe.Title);
            recipe.imageUrl = imageUrl || '/path/to/default/image.jpg';
            recipe.recipeId = recipe.RecipeID;
        }

        for (let review of reviews) {
            const reviewedRecipe = await RecipeService.getRecipeDetails(review.RecipeID);
            review.recipeTitle = reviewedRecipe.Title;
            review.recipeId = reviewedRecipe.RecipeID;
            review.imageUrl = await getPixabayImages(review.recipeTitle) || '/path/to/default/image.jpg';
            review.reviewId = review.ReviewID;
        }

        res.status(200).json({
            joinDate: formattedJoinDate,
            username: username,
            bio: bio,
            recipes: recipes,
            reviews: reviews
        });
    } catch (error) {
        console.error("Error loading user profile:", error);
        res.status(500).json({ error: "Error loading user profile" });
    }
};

// controller to handle updating user's bio
const updateUserBioController = async (req, res) => {
    const token = req.headers['authorization']?.split(' ')[1];
    const userId = getUserIdFromToken(token);

    if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
    }

    const { newBio } = req.body;

    try {
        const username = await UserService.getUsernameByUserId(userId);
        const result = await UserService.updateUserBio(username, newBio);

        res.status(200).json({ message: "User bio updated successfully", result });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// controller to handle getting user from username
const getUserByUsernameController = async (req, res) => {
    const { username } = req.params;

    try {
        const user = await UserService.getUserByUsername(username);
        res.status(200).json(user);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// controller to handle getting user join date
const getUserJoinDateController = async (req, res) => {
    const { username } = req.params;

    try {
        const joinDate = await UserService.getUserJoinDate(username);
        const formattedJoinDate = moment(joinDate).format('DD/MM/YY');
        res.status(200).json({ joinDate: formattedJoinDate });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// controller to handle getting user bio
const getUserBioController = async (req, res) => {
    const { username } = req.params;

    try {
        const bio = await UserService.getUserBio(username);
        res.status(200).json({ bio });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

module.exports = {
    userProfileController,
    updateUserBioController,
    viewUserProfileController,
    getUserByUsernameController,
    getUserJoinDateController,
    getUserBioController
};
