const {
    createRecipe,
    getRecipesByCriteria,
    getRecipesByUser,
    getRecipeDetails,
    searchRecipes
} = require('../Services/RecipeService');

const { getCuisineIdByName, getCuisineNameById } = require('../Services/CuisineService');
const { getUserIdByUsername, getUsernameByUserId } = require('../Services/UserService');
const { getPixabayImages } = require('../External API/recipeImage'); 
const jwt = require('jsonwebtoken');

// controller to handle getting user id from genrated token
const getUserIdFromToken = (token) => {
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        return decoded.userId; 
    } catch (error) {
        return null; 
    }
};


// controller to handle creation of recipe
const createRecipeController = async (req, res) => {
    const recipeData = req.body;

    try {
        const token = req.headers['authorization']?.split(' ')[1]; 
        const userId = getUserIdFromToken(token); 

        if (!userId) {
            return res.status(401).json({ error: 'Unauthorized' });
        }

        const cuisineId = await getCuisineIdByName(recipeData.cuisineName);

        if (!cuisineId) {
            return res.status(400).json({ error: 'Invalid cuisine name' });
        }

        const newRecipeData = {
            ...recipeData,
            cuisineID: cuisineId,
            userID: userId
        };

        const result = await createRecipe(newRecipeData);
        res.status(201).json({ message: "Recipe created successfully!", recipe: result });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};


// controller to handle getting recipes by criteria
const getRecipesByCriteriaController = async (req, res) => {
    const { dietaryPreferences, calorieLimitPerMeal, preferredCuisine } = req.body;
    try {
        const token = req.headers['authorization']?.split(' ')[1];
        const userId = getUserIdFromToken(token);

        if (!userId) {
            return res.status(401).json({ error: 'Unauthorized' });
        }

        const cuisineId = await getCuisineIdByName(preferredCuisine);

        if (!cuisineId) {
            return res.status(404).json({ error: 'Cuisine not found' });
        }

        const recipes = await getRecipesByCriteria(dietaryPreferences, calorieLimitPerMeal, cuisineId);

        res.status(200).json(recipes);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};


// controller to handle getting recipes by specific user
const getRecipesByUserController = async (req, res) => {
    const { username } = req.params;
    try {
        const token = req.headers['authorization']?.split(' ')[1];
        const userId = getUserIdFromToken(token);

        if (!userId) {
            return res.status(401).json({ error: 'Unauthorized' });
        }

        const recipes = await getRecipesByUser(username);
        res.status(200).json(recipes);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// controller to handle getting recipes' details
const getRecipeDetailsController = async (req, res) => {
    const recipeId = req.query.recipeId;

    try {
        const token = req.headers['authorization']?.split(' ')[1];
        const userId = getUserIdFromToken(token); 

        if (!userId) {
            return res.status(401).json({ error: 'Unauthorized' });
        }

        const recipe = await getRecipeDetails(recipeId);
        if (!recipe) {
            return res.status(404).json({ error: "Recipe not found" });
        }

        const cuisineName = await getCuisineNameById(recipe.CuisineID);
        recipe.cuisineName = cuisineName;

        // gets the image URL using external API
        const imageUrl = await getPixabayImages(recipe.Title);
        recipe.imageUrl = imageUrl || '/path/to/default/image.jpg';

        if (recipe.UserID) {
            const username = await getUsernameByUserId(recipe.UserID);
            recipe.Username = username;
        } else {
            recipe.Username = "Recipe Roulette";
        }

        res.status(200).json({
            recipe,
            imageUrl: recipe.imageUrl,
            Username: recipe.Username
        });
    } catch (error) {
        console.error("Error fetching recipe details:", error);
        res.status(500).json({ error: "Error fetching recipe details" });
    }
};

// controller to handle searching for recipes in search query
const searchRecipesController = async (req, res) => {
    const { searchQuery } = req.query;

    try {
        const token = req.headers['authorization']?.split(' ')[1];
        const userId = getUserIdFromToken(token); 

        if (!userId) {
            return res.status(401).json({ error: 'Unauthorized' });
        }

        const recipes = await searchRecipes(searchQuery);

        for (let recipe of recipes) {
            const cuisineName = await getCuisineNameById(recipe.CuisineID);
            const imageUrl = await getPixabayImages(recipe.Title);

            recipe.cuisineName = cuisineName;
            recipe.imageUrl = imageUrl || '/path/to/default/image.jpg';
        }

        res.status(200).json(recipes);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

module.exports = {
    createRecipeController,
    getRecipesByCriteriaController,
    getRecipesByUserController,
    getRecipeDetailsController,
    searchRecipesController
};
