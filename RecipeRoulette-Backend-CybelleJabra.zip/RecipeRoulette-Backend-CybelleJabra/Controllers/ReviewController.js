const { 
    createReview, 
    getReviewsByRecipeId, 
    getReviewsByUser, 
    updateAverageRating, 
    deleteReview 
} = require("../Services/ReviewService");
const { getUserIdByUsername } = require("../Services/UserService");
const moment = require('moment');
const jwt = require('jsonwebtoken');

const getUserIdFromToken = (token) => {
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        return decoded.userId; 
    } catch (error) {
        return null; 
    }
};

const createReviewController = async (req, res) => {
    const token = req.headers['authorization']?.split(' ')[1]; 
    const userId = getUserIdFromToken(token); 

    if (!userId) {
        return res.status(401).json({ error: "User not authenticated" }); 
    }

    try {
        const reviewData = req.body;
        reviewData.userID = userId; 
        reviewData.reviewDate = new Date();

        const result = await createReview(reviewData);
        await updateAverageRating(reviewData.recipeID); 

        res.status(201).json({ message: "Review created successfully", reviewId: result.review_id });
    } catch (error) {
        console.error("Error creating review:", error);
        res.status(400).json({ error: error.message });
    }
};

const getReviewsByRecipeIdController = async (req, res) => {
    const { recipeId } = req.params;

    try {
        const reviews = await getReviewsByRecipeId(recipeId);

        const formattedReviews = reviews.map(review => ({
            ...review,
            formattedDate: moment(review.ReviewDate).format('DD/MM/YY') 
        }));

        res.status(200).json({ reviews: formattedReviews, recipeId });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getReviewsByUserController = async (req, res) => {
    const token = req.headers['authorization']?.split(' ')[1]; 
    const userId = getUserIdFromToken(token); 

    if (!userId) {
        return res.status(401).json({ error: "User not authenticated" }); 
    }

    const { username } = req.params;

    try {
        const reviews = await getReviewsByUser(username);

        const formattedReviews = reviews.map(review => ({
            ...review,
            formattedDate: moment(review.ReviewDate).format('DD/MM/YY') 
        }));

        res.status(200).json({ reviews: formattedReviews });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteReviewController = async (req, res) => {
    const { reviewId, recipeId } = req.params;

    const token = req.headers['authorization']?.split(' ')[1];
    const userId = getUserIdFromToken(token);
    if (!userId) {
        return res.status(401).json({ error: "User not authenticated" }); 
    }

    try {
        await deleteReview(reviewId);
        await updateAverageRating(recipeId); 

        res.status(200).json({ message: "Review deleted successfully" });
    } catch (error) {
        console.error("Error deleting review:", error);
        res.status(400).json({ error: error.message });
    }
};

module.exports = {
    createReviewController,
    getReviewsByRecipeIdController,
    getReviewsByUserController,
    deleteReviewController  
};
