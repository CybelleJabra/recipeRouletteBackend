const { getCuisines, getCuisineIdByName, getCuisineNameById } = require("../Services/CuisineService");

// controller to handle getting all cuisines
const getCuisinesController = async (req, res) => {
    try {
        const cuisines = await getCuisines();
        res.status(200).json({ cuisines }); 
    } catch (error) {
        res.status(500).json({ error: "Error fetching cuisines" });
    }
};


// controller to handle getting cuisine ID from its name
const getCuisineIdByNameController = async (req, res) => {
    const { cuisineName } = req.params; 
    try {
        const cuisineId = await getCuisineIdByName(cuisineName);
        if (cuisineId) {
            res.json({ cuisineId });
        } else {
            res.status(404).json({ message: "Cuisine not found" });
        }
    } catch (error) {
        res.status(500).json({ message: `Error fetching cuisine ID: ${error.message}` });
    }
};


// controller to handle getting cuisine name from its ID
const getCuisineNameByIdController = async (req, res) => {
    const { cuisineId } = req.params; 

    try {
        const cuisineName = await getCuisineNameById(cuisineId);
        res.status(200).json({ cuisineName }); 
    } catch (error) {
        if (error.message.includes("Cuisine not found")) {
            res.status(404).json({ error: "Cuisine not found" });
        } else {
            res.status(500).json({ error: `Error retrieving cuisine name: ${error.message}` });
        }
    }
};

module.exports = {
    getCuisinesController,
    getCuisineIdByNameController,
    getCuisineNameByIdController
};
