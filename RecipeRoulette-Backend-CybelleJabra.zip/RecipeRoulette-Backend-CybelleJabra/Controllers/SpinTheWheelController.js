const SpinService = require("../Services/SpinTheWheelService");

// controller to handle the spin the wheel service
const spinTheWheelController = async (req, res) => {
    const { dietaryPreferences, calories, cuisineId } = req.body;

    try {
        const randomRecipe = await SpinService.spinTheWheel(dietaryPreferences, calories, cuisineId);

        if (!randomRecipe) {
            console.log("No recipe found, sending failure response.");
            return res.status(404).json({ success: false, message: "No Recipe Found By These Requirements at This Time" });
        }

        const recipeId = randomRecipe.RecipeID;

        res.json({ success: true, message: "Recipe Found!", recipeId, recipe: randomRecipe });
    } catch (error) {
        console.error("Error spinning the wheel:", error);
        res.status(500).json({ success: false, message: "Error spinning the wheel: " + error.message });
    }
}

module.exports = { spinTheWheelController };
