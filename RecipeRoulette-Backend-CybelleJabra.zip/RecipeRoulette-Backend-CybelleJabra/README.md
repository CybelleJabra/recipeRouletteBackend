1. Project Setup Instructions:
First, you must have Node.js (version 12 or higher) and npm (Node Package Manager)
Then use this command to clone to the repository: git clone <https://github.com/cybellejabra217/reciperoulette.git>
Navigate to project directory: cd reciperoulette
Create the necessary .env file to properly configure the database
Then: npm install and npm install -g nodemon
And finally: "npm/nodemon app" to run the server on port 3001
Prefer to use nodemon app since it just restarts when something is changed in the code or if it reaches an error, it doesn't need to be run again like npm app

2. API Endpoints and Usage:

 GET/getCuisines: to retrieve all cuisines in database

 POST/register: to register a user with his inputted credentials into the database
 POST/login: to login a user

 POST/createRecipe : to create a recipe and put it in the database
 GET/getRecipesByCuisine/:cuisineName : to retrieve all recipes belonging to a specific cuisineName
 GET/getRecipesByIngredients/:ingredientName : to retrieve all recipes that include a specific ingredient
 GET/getRecipesByDietaryPreferences/:dietaryPreferences : to retrieve all recipes with a dietary preference
 GET/getPicturesByRecipe/:recipeId : to retrieve the pictures that belong to a specific recipeID
 GET/getRecipesByCriteria : to retrieve all recipes from database with that specific criteria

 POST/createReview : to create a review and put it in the database
 GET/getReviewsByRecipe/:recipeId : to retrieve all reviews that belong to a specific recipeID
 GET/getReviewsByUser/:userId  : to retrieve all reviews that belong to a specific userID
 GET/spinTheWheel : to retrieve a random recipe that fits the criteria of the user
 POST/updateUserBio : to update the bio of a specific user