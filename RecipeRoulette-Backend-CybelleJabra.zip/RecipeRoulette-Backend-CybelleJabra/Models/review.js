const { DataTypes } = require('sequelize');
const sequelize = require('../Config/DBConfig');

// uses sequelize to interact with model Review in database
const Review = sequelize.define('Review', {
    ReviewID: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false,
    },
    Content: {
        type: DataTypes.TEXT,
        allowNull: true, 
    },
    ReviewDate: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW, 
    },
    RecipeID: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    UserID: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    Value: {
        type: DataTypes.INTEGER,
        allowNull: false, 
        validate: {
            min: 1, 
            max: 5, 
        },
    },
}, {
    tableName: 'review', 
    timestamps: false, 
});

Review.associate = (models) => {
    Review.belongsTo(models.User, {
        foreignKey: 'UserID',
        as: 'user', 
    });

    Review.belongsTo(models.Recipe, {
        foreignKey: 'RecipeID',
        as: 'recipe', 
    });
};

module.exports = Review;
