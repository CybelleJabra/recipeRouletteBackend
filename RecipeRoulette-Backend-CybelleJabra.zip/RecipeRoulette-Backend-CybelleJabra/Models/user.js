const { DataTypes } = require('sequelize');
const sequelize = require('../Config/DBConfig');

// uses sequelize to interact with model User in database
const User = sequelize.define('User', {
    UserID: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false,
    },
    Username: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    Password: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    Email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
        validate: {
            isEmail: true,
        },
    },
    JoinDate: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
    },
    Bio: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
}, {
    tableName: 'user', 
    timestamps: false,
});

module.exports = User;
