const { DataTypes } = require('sequelize');
const sequelize = require('../Config/DBConfig');
const Cuisine = require('./cuisine');
const User = require('./user');

// uses sequelize to interact with model Recipe in database
const Recipe = sequelize.define('Recipe', {
    RecipeID: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false,
    },
    Title: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    Description: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    Ingredients: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    Instructions: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    DifficultyLevel: {
        type: DataTypes.ENUM('easy', 'moderate', 'hard'), 
        allowNull: true,
    },
    AverageRating: {
        type: DataTypes.DECIMAL(3, 2),
        allowNull: true,
    },
    CuisineID: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    Calories: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    UserID: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    DietaryPreferences: {
        type: DataTypes.ENUM('Vegan', 'Vegetarian', 'Pescetarian', 'Gluten-Free', 'Lactose-Free', 'None'), 
    },
}, {
    tableName: 'recipe',
    timestamps: false,
});

Recipe.belongsTo(User, {
    foreignKey: 'UserID',
    as: 'user',
});

Recipe.belongsTo(Cuisine, {
    foreignKey: 'CuisineID',
    as: 'cuisine',
});

module.exports = Recipe;
