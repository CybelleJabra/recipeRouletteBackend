const { DataTypes } = require('sequelize');
const sequelize = require('../Config/DBConfig');

// uses sequelize to interact with model Cuisine in database
const Cuisine = sequelize.define('Cuisine', {
    CuisineID: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false,
    },
    CuisineName: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
}, {
    tableName: 'cuisine',
    timestamps: false,
});

module.exports = Cuisine;
