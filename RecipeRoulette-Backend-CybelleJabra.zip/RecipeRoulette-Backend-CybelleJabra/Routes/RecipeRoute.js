const express = require('express');
const router = express.Router();
const {
    createRecipeController,
    getRecipesByCriteriaController,
    getRecipesByUserController,
    getRecipeDetailsController,
    searchRecipesController
} = require('../Controllers/RecipeController');
const { recipeValidation } = require('../Validators/RecipeValidator');

// ensure validity and security of routes
const authenticateJWT = require('../middleware/authenticateMiddleware'); 

// route to create a recipe
router.post('/createRecipe', recipeValidation, authenticateJWT, createRecipeController);

// route to get recipes by criteria
router.get('/recipesByCriteria', recipeValidation, authenticateJWT, getRecipesByCriteriaController);

// route to get recipes submitted by user
router.get('/recipesByUser/:username', recipeValidation, authenticateJWT, getRecipesByUserController);

// route to get recipe details for a recipe
router.get('/recipedetails', authenticateJWT, getRecipeDetailsController);

// route to search for recipes in search query
router.get('/searchRecipes', authenticateJWT, searchRecipesController);


module.exports = router;
 