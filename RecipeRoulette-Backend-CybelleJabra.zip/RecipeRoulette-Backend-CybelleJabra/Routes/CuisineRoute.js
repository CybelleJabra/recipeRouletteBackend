const express = require('express');
const router = express.Router();
const {
    getCuisinesController,
    getCuisineIdByNameController,
    getCuisineNameByIdController,
} = require('../Controllers/CuisineController');

// ensure validity and security of routes
const authenticateJWT = require('../middleware/authenticateMiddleware'); 

// route to get cuisineID from name
router.get('/getCuisineIdByName/:cuisineName', authenticateJWT, getCuisineIdByNameController);

// route to get cuisineName from ID
router.get('/getCuisineNameById/:cuisineId', authenticateJWT, getCuisineNameByIdController);

// route to get all cuisines
router.get('/getAllCuisines', authenticateJWT, getCuisinesController);

module.exports = router;
