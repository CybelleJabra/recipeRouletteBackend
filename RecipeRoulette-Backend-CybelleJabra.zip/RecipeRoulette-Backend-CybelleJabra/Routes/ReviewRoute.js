const express = require('express');
const router = express.Router();
const { 
    createReviewController,
    getReviewsByRecipeIdController,
    getReviewsByUserController,
    deleteReviewController
} = require('../Controllers/ReviewController');
const { reviewValidation } = require('../Validators/ReviewValidator');

// ensure validity and security of routes
const authenticateJWT = require('../middleware/authenticateMiddleware'); 

// route to create review
router.post('/createReview', reviewValidation, authenticateJWT, createReviewController);

// route to get reviews for a specific recipe
router.get('/getReviewsByRecipe/:recipeId', authenticateJWT, getReviewsByRecipeIdController);

// route to get reviews by a specific user
router.get('/getReviewsByUser/:username', authenticateJWT, getReviewsByUserController);

// route to delete review
router.post('/deleteReview/:reviewId/:recipeId', authenticateJWT, deleteReviewController);

module.exports = router;
