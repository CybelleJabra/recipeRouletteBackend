const express = require('express');
const router = express.Router();
const { registerUserController, loginUserController } = require('../Controllers/LoginController');
const { loginValidation } = require('../Validators/LoginValidator');

// route to register a user
router.post('/register', loginValidation, registerUserController);

// route to login a user
router.post('/login', loginUserController);

module.exports = router;
