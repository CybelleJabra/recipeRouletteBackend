const express = require('express');
const router = express.Router();
const { spinTheWheelController } = require('../Controllers/SpinTheWheelController');

// ensure validity and security of routes
const authenticateJWT = require('../middleware/authenticateMiddleware'); 

// route to spin the wheel and get random recipe
router.post('/spinTheWheel', authenticateJWT, spinTheWheelController);

module.exports = router;
