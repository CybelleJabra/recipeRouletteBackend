const express = require('express');
const router = express.Router();
const {
    userProfileController,
    updateUserBioController,
    viewUserProfileController,
    getUserByUsernameController,
    getUserJoinDateController,
    getUserBioController
} = require('../Controllers/UserController');

// ensure validity and security of routes
const authenticateJWT = require('../middleware/authenticateMiddleware');

// route to retrieve details for the logged in user's profile
router.get('/myProfile', authenticateJWT, userProfileController);

// route to retrieve details for another user's profile
router.get('/userProfile/:username', authenticateJWT, viewUserProfileController);

// route to update user's bio
router.post('/updateUserBio', authenticateJWT, updateUserBioController);

// route to get user by username
router.get('/getUserByUsername/:username', authenticateJWT, getUserByUsernameController);

// route to get user's join date
router.get('/getUserJoinDate/:username', authenticateJWT, getUserJoinDateController);

// route to get user's bio
router.get('/getUserBio/:username', authenticateJWT, getUserBioController);

module.exports = router;
