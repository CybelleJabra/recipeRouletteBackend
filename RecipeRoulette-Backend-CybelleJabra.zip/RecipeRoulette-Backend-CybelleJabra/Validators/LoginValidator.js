const { check } = require('express-validator');

// validation check for username and password
const loginValidation = [
    check('username').notEmpty().withMessage('Username is required'),
    check('password').isLength({min: 6}).withMessage("Passwords must be at least 6 characters long")
];

module.exports = {
    loginValidation
}