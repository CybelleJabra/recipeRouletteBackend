// importing all needed technologies
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const dotenv = require("dotenv");


dotenv.config();

const app = express();

// to be able to communicate with frontend even on different ports
app.use(cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// importing all APIs
const cuisineRoutes = require('./Routes/CuisineRoute');
const loginRoutes = require('./Routes/LoginRoute');
const recipeRoutes = require('./Routes/RecipeRoute');
const userRoutes = require('./Routes/UserRoute');
const reviewRoutes = require('./Routes/ReviewRoute');
const spinTheWheelRoutes = require('./Routes/SpinTheWheelRoute');

app.use(loginRoutes);
app.use(cuisineRoutes);
app.use(recipeRoutes);
app.use(userRoutes);
app.use(reviewRoutes);
app.use(spinTheWheelRoutes);

const PORT = process.env.PORT || 4000;

// running server on a port
app.listen(PORT, () => {
    console.log(`====================================`);
    console.log(`Server running on port ${PORT}`);
    console.log(`====================================`);
});
