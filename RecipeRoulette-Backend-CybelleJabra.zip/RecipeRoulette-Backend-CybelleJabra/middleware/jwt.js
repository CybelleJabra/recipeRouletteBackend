const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');

// secret key found in .env file
const SECRET_KEY = process.env.SECRET_KEY; 

// generates a token when a user logs in 
const generateToken = (payload) => {
    const secret = process.env.JWT_SECRET;
    if (!secret) {
        throw new Error("JWT_SECRET is not defined in environment variables");
    }
    return jwt.sign(payload, secret, { expiresIn: '1h' });
};

// verifies the token
const verifyToken = (token) => {
    try {
        const decoded = jwt.verify(token, SECRET_KEY);
        return decoded;
    } catch (error) {
        throw new Error('Invalid or expired token');
    }
};

module.exports = {
    generateToken,
    verifyToken,
};
