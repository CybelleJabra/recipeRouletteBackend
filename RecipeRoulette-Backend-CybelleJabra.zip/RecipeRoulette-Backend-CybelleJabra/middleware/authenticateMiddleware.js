const { verifyToken } = require('./jwt'); 

// utilized for added route security and validity
const authenticateJWT = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1]; 

    if (!token) {
        return res.sendStatus(403); 
    }

    try {

        // verifies a token has been generated
        const user = verifyToken(token);
        req.user = user; 
        next();
    } catch (error) {
        res.sendStatus(401); 
    }
};

module.exports = authenticateJWT;
